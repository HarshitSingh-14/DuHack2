module.exports = {
  MONGOURI:
    "",
  JWT_SECRET: "",
};
